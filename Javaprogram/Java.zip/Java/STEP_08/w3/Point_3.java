package point;

public class Point_3{
    int x;
    int y;
    public Point_3(int x, int y){
        this.x = x; this.y = y;
    }
    public int get_x(){
        return x;
    }
    public int get_y(){
        return y;
    }
}
