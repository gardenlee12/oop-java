package kor.point;

public class Point_5{
    private int x;
    private int y;

    public Point_5(int x, int y){
        this.x = x; this.y = y;
    }
    public int get_x() {return x;}
    public int get_y() {return y;}
}