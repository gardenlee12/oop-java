package point;

public class point_4{

    private int x;
    private int y;

    public Point_4(int x, int y){
        this.x = x; this.y = y;
    }
    public int get_x(){
        return x;
    }
    public int get_y(){
        return y;
    }
}