import java.io.*;
/*
class Add_41{
    int add2i(int a,int b) {
        int total;
        int s;
        s = a + b;
        total += s;
        return (s);
    }
}

class Add_42{
    int add2i(int a, int b) {
        static int total;
        int s;
        s = a + b;
        total += s;
        return(s);
    }
}
*/
class Add_43{
    int total;
    int add2i(int a, int b) {
        int s;
        s = a + b;
        total += s;
        return(s);
    }
}