package kor.ptln;

public class Point_5 {
    public int x;
    public int y;

    public Point_5(int x, int y) {this.x = x; this.y = y; }
    
    void set_xy(int x, int y) {this.x = x; this.y = y; }
    void set_x(int x) {this.x = x;}
    void set_y(int y) {this.y = y; }
    int get_x() {return x;}
    int get_y() {return y;}
}