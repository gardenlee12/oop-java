import java.io.*;

pakage work;

class Add_2{
    int total;

    public int add2c(int a, int b){
        int s;
        s = a + b;
        total += s;
        return(s);
    }

    public float add2c(float a, float b){
        float s;
        s = a + b;
        total += s;
        return(s);
    }

}